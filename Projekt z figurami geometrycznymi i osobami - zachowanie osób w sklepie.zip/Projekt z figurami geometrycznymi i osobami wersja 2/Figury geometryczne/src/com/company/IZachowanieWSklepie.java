package com.company;

import java.util.ArrayList;

public interface IZachowanieWSklepie {
    public double kupuj(double kwotaDoWydania, ArrayList<Towar> towary);
}
